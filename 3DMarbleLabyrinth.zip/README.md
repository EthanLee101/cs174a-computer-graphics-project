<img width="2385" height="1299" alt="image" src="image.png" />
run 
`npm install`
and 
`npm run dev` 
to get it up and running
